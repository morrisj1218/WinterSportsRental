﻿Public Class frmCustomer
    Private Sub btnCheckout_Click(sender As Object, e As EventArgs) 

        Dim strName As String = txtName.Text.ToString.Trim
        Dim strAddress As String = txtAddress.Text.ToString.Trim
        Dim strCity As String = txtCity.Text.ToString.Trim
        Dim strState As String = txtState.Text.ToString.Trim
        Dim strZip As String = txtZip.Text.ToString.Trim
        Dim strPhone As String = txtPhone.Text.ToString.Trim
        Dim strCardNum As String = txtCardNum.Text.ToString.Trim

        Dim cust As New Customer(strName, strAddress, strCity, strState, strZip,
                                  strPhone, strCardNum)

        Dim ofCustomerInfo As IO.StreamWriter
        ofCustomerInfo = IO.File.AppendText("customerInfo.txt")

        ofCustomerInfo.WriteLine(strName)
        ofCustomerInfo.WriteLine(strAddress)
        ofCustomerInfo.WriteLine(strCity & " " & strState & ", " & strZip)
        ofCustomerInfo.WriteLine(strPhone)
        ofCustomerInfo.WriteLine(strCardNum)
        ofCustomerInfo.WriteLine()
        ofCustomerInfo.Close()

        frmSummary.Show()

    End Sub

    Private Sub btnBack_Click(sender As Object, e As EventArgs) 

        Me.Close()

    End Sub

    Private Sub CustomersBindingNavigatorSaveItem_Click(sender As Object, e As EventArgs) Handles CustomersBindingNavigatorSaveItem.Click
        Me.Validate()
        Me.CustomersBindingSource.EndEdit()
        Me.TableAdapterManager.UpdateAll(Me.WinterSportsDataSet)

    End Sub

    Private Sub frmCustomer_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'WinterSportsDataSet.Customers' table. You can move, or remove it, as needed.
        Me.CustomersTableAdapter.Fill(Me.WinterSportsDataSet.Customers)

    End Sub
End Class