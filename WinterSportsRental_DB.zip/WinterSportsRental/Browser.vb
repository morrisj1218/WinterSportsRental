﻿

Public Class frmBrowser

    Private Sub frmBrowser_Load(sender As Object, e As EventArgs) Handles Me.Load
        webBrowser.ScriptErrorsSuppressed = True
    End Sub

End Class